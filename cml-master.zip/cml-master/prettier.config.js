module.exports = {
  arrowParens: 'always',
  singleQuote: true,
  trailingComma: 'none',
  printWidth: 80,
  tabWidth: 2,
  useTabs: false,
  proseWrap: 'always'
};
